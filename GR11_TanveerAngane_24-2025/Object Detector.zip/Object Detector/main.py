# from ultralytics import YOLO 
# import cvzone
# import cv2

# # Load the model
# model = YOLO('yolov10n.pt')

# # Live webcam
# cap = cv2.VideoCapture(0)

# while True:
#     ret, image = cap.read()
#     if not ret:
#         print("Failed to grab frame")
#         continue
    
#     results = model(image)
    
#     for info in results:
#         parameters = info.boxes
#         for box in parameters:
#             x1, y1, x2, y2 = box.xyxy[0].numpy().astype('int')
#             confidence = box.conf[0].numpy().astype('float') * 100
#             class_detected_number = int(box.cls[0])
#             class_detected_name = results[0].names[class_detected_number]

#             # Draw the rectangle and text inside the loop
#             cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 3)
#             cvzone.putTextRect(image, f'{class_detected_name} {confidence:.2f}%', 
#                                [x1 + 8, y1 - 12], thickness=2, scale=1.5)

#     cv2.imshow('frame', image)
    
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()



from flask import Flask, jsonify
from flask_cors import CORS
import subprocess
import platform

app = Flask(__name__)
CORS(app)  # Enable CORS

@app.route('/start-detection', methods=['GET'])
def start_detection():
    try:
        if platform.system() == "Windows":
            subprocess.Popen(['start', 'cmd', '/k', 'python', 'detector.py'], shell=True)  # Open a new terminal window
        else:
            subprocess.Popen(['python3', 'detector.py'])  # For Linux/macOS
        
        return jsonify({"message": "YOLO detection started in a new window."})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
